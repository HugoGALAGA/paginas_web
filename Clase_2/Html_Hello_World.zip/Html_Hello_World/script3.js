document.addEventListener('DOMContentLoaded', function() {
    
    // Configuración del Lienzo (Canvas)
    const canvas = document.getElementById('nightSkyCanvas');
    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    // Configuración del Cursor Personalizado
    let cursor = { x: -100, y: -100 };
    const customCursorDiv = document.createElement('div');
    customCursorDiv.classList.add('custom-cursor');
    document.body.appendChild(customCursorDiv);

    document.addEventListener('mousemove', e => {
        cursor.x = e.clientX;
        cursor.y = e.clientY;
        customCursorDiv.style.left = `${e.clientX - 5}px`;
        customCursorDiv.style.top = `${e.clientY - 5}px`;
    });

    // Clase para las Partículas (Luciérnagas)
    class Particle {
        constructor(x, y, size, color, speedX, speedY) {
            this.x = x;
            this.y = y;
            this.size = size;
            this.color = color;
            this.speedX = speedX;
            this.speedY = speedY;
        }

        draw() {
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2, false);
            ctx.fillStyle = this.color;
            ctx.fill();
        }

        update() {
            if (this.x > canvas.width || this.x < 0) this.speedX = -this.speedX;
            if (this.y > canvas.height || this.y < 0) this.speedY = -this.speedY;

            this.x += this.speedX;
            this.y += this.speedY;

            // Interacción con el cursor
            let dx = this.x - cursor.x;
            let dy = this.y - cursor.y;
            let distance = Math.sqrt(dx * dx + dy * dy);

            if (distance < 100) { // Si el cursor está cerca
                this.x += dx / 20; // Se aleja
                this.y += dy / 20;
            }
        }
    }

    // Creación de las partículas
    let particlesArray = [];
    const numberOfParticles = 100;

    for (let i = 0; i < numberOfParticles; i++) {
        let size = Math.random() * 2 + 1;
        let x = Math.random() * canvas.width;
        let y = Math.random() * canvas.height;
        let speedX = (Math.random() - 0.5) * 0.5;
        let speedY = (Math.random() - 0.5) * 0.5;
        let color = 'rgba(255, 255, 224, 0.7)';
        particlesArray.push(new Particle(x, y, size, color, speedX, speedY));
    }

    // Bucle de Animación
    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        for (let particle of particlesArray) {
            particle.update();
            particle.draw();
        }
        requestAnimationFrame(animate);
    }

    // Iniciar la animación
    animate();

    // Redimensionar el canvas si cambia el tamaño de la ventana
    window.addEventListener('resize', () => {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    });
});